// backend/models/Quiz.js
const mongoose = require("mongoose");

const questionSchema = new mongoose.Schema({
  question: { type: String, required: true },
  options: [{ type: String, required: true }],
  answer: { type: Number, required: true } // index of correct option
});

const quizSchema = new mongoose.Schema({
  lessonId: { type: String, required: true, unique: true}, // maps to Lesson.lessonId
  questions: { type: [questionSchema], required: true }
}, { timestamps: true });

module.exports = mongoose.model("Quiz", quizSchema);
