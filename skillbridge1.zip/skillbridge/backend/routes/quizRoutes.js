// backend/routes/quizRoutes.js
const express = require("express");
const router = express.Router();
const Quiz = require("../models/Quiz");

// create quiz for a lesson (POST /quizzes)
router.post("/", async (req, res) => {
  try {
    const { lessonId, questions } = req.body;
    if (!lessonId || !Array.isArray(questions) || questions.length === 0) {
      return res.status(400).json({ message: "lessonId and questions[] required" });
    }

    // simple upsert: if a quiz exists for lessonId, we could return conflict or replace
    // here we'll create new quiz (you can change to upsert if needed)
    const quiz = new Quiz({ lessonId: lessonId.trim(), questions });
    await quiz.save();
    res.status(201).json(quiz);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error creating quiz" });
  }
});

// get quiz by lessonId (GET /quizzes/:lessonId)
router.get("/:lessonId", async (req, res) => {
  try {
    const quiz = await Quiz.findOne({ lessonId: req.params.lessonId });
    if (!quiz) return res.status(404).json({ message: "No quiz found for this lesson" });
    res.json(quiz);
  } catch (err) {
    res.status(500).json({ message: "Error fetching quiz" });
  }
});

// optionally: get all quizzes
router.get("/", async (req, res) => {
  try {
    const quizzes = await Quiz.find();
    res.json(quizzes);
  } catch (err) {
    res.status(500).json({ message: "Error fetching quizzes" });
  }
});

module.exports = router;
