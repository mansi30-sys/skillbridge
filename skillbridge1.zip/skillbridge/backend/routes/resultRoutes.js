// backend/routes/resultRoutes.js
const express = require("express");
const router = express.Router();

// In-memory storage
let resultData = {};

router.post("/", (req, res) => {
  const { user, question, userAnswer, correctAnswer, correct } = req.body;

  if (!user) return res.status(400).json({ message: "User is required" });

  if (!resultData[user]) {
    resultData[user] = [];
  }

  resultData[user].push({ question, userAnswer, correctAnswer, correct });

  res.json({ message: "Result saved successfully" });
});

router.get("/:user", (req, res) => {
  const { user } = req.params;
  res.json(resultData[user] || []);
});

module.exports = router;
