// backend/routes/lessonRoutes.js
const express = require("express");
const router = express.Router();
const Lesson = require("../models/Lesson");

// Create lesson (POST /lessons)
router.post("/", async (req, res) => {
  try {
    const { lessonId, title, description, fullContent, videoUrl, imageUrl } = req.body;
    if (!lessonId || !title) {
      return res.status(400).json({ message: "lessonId and title are required" });
    }

    // prevent duplicate lessonId
    const exists = await Lesson.findOne({ lessonId: lessonId.trim() });
    if (exists) return res.status(409).json({ message: "lessonId already exists" });

    const lesson = new Lesson({
      lessonId: lessonId.trim(),
      title, description, fullContent, videoUrl, imageUrl
    });

    await lesson.save();
    res.status(201).json(lesson);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error creating lesson" });
  }
});

// Get all lessons (GET /lessons)
router.get("/", async (req, res) => {
  try {
    const lessons = await Lesson.find().sort({ createdAt: 1 });
    res.json(lessons);
  } catch (err) {
    res.status(500).json({ message: "Error fetching lessons" });
  }
});

// Get lesson by ID
router.get('/:id', async (req, res) => {
  try {
    const lesson = await Lesson.findById(req.params.id);
    if (!lesson) {
      return res.status(404).json({ message: "Lesson not found" });
    }
    res.json(lesson);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});


// Update a lesson completely (PUT)
router.put("/:lessonId", async (req, res) => {
  try {
    const updatedLesson = await Lesson.findOneAndUpdate(
      { lessonId: req.params.lessonId },
      req.body,
      { new: true }
    );
    if (!updatedLesson) return res.status(404).json({ message: "Lesson not found" });
    res.json(updatedLesson);
  } catch (err) {
    res.status(500).json({ message: "Error updating lesson" });
  }
});

// Partially update lesson (PATCH)
router.patch("/:lessonId", async (req, res) => {
  try {
    const updatedLesson = await Lesson.findOneAndUpdate(
      { lessonId: req.params.lessonId },
      { $set: req.body },
      { new: true }
    );
    if (!updatedLesson) return res.status(404).json({ message: "Lesson not found" });
    res.json(updatedLesson);
  } catch (err) {
    res.status(500).json({ message: "Error patching lesson" });
  }
});

// Delete a lesson
router.delete("/:lessonId", async (req, res) => {
  try {
    const deletedLesson = await Lesson.findOneAndDelete({ lessonId: req.params.lessonId });
    if (!deletedLesson) return res.status(404).json({ message: "Lesson not found" });
    res.json({ message: "Lesson deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: "Error deleting lesson" });
  }
});

module.exports = router;
