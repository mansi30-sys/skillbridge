const path = require('path');
const express = require('express');
require('dotenv').config({ path: path.join(__dirname, '.env') });
const connectDB = require('./config/db');
const cors = require("cors");

// Import routes
const authRoutes = require('./routes/authRoutes');
const lessonRoutes = require('./routes/lessonRoutes');
const quizRoutes = require('./routes/quizRoutes');
const resultRoutes = require('./routes/resultRoutes');
const feedbackRoutes = require('./routes/feedbackRoutes'); // 🆕 Added

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(cors());

// Connect to MongoDB
connectDB();

// API Routes
app.use('/auth', authRoutes);      
app.use('/lessons', lessonRoutes); 
app.use('/quizzes', quizRoutes);   
app.use('/results', resultRoutes);
app.use('/Feedback', feedbackRoutes); // 🆕 Added feedback route


// 👉 Serve frontend static files
app.use(express.static(path.join(__dirname, "../frontend")));

// Health check
app.get('/api', (req, res) => {
  res.send('✅ SkillBridge Backend API is running...');
});

// 👉 Catch-all route (for direct page loads)
app.get(/.*/, (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend", "index.html"));
});

// Start server
app.listen(PORT, () => console.log(`✅ Server running at http://localhost:${PORT}`));
