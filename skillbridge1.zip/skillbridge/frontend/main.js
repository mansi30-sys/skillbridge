// ✅ No hardcoded backend URL (same port serves frontend + backend)
const BASE_URL = "";

// ================= LESSONS PAGE =================
async function loadLessons() {
  const lessonContainer = document.getElementById("lessonsList");
  if (!lessonContainer) return;

  try {
    const res = await fetch(`/lessons`);
    const lessons = await res.json();

    lessonContainer.innerHTML = "";

    lessons.forEach((lesson) => {
      const div = document.createElement("div");
      div.className = "lesson-card";
      div.innerHTML = `
        <h3>${lesson.title}</h3>
        <p>${lesson.description}</p>
        <button onclick="viewContent('${lesson.content}')">View Content</button>
        <label>
          <input type="checkbox" onchange="unlockQuiz('${lesson._id}')"> Mark Completed
        </label>
        <div id="quiz-${lesson._id}" class="quiz-section" style="display:none; margin-top:10px;"></div>
      `;
      lessonContainer.appendChild(div);
    });
  } catch (err) {
    lessonContainer.innerHTML = "<p>Error loading lessons</p>";
  }
}

// Show lesson content (simple alert for now, can be modal)
function viewContent(content) {
  alert(content);
}

// Unlock quiz section after marking lesson complete
async function unlockQuiz(lessonId) {
  await completeLesson();
  const quizDiv = document.getElementById(`quiz-${lessonId}`);
  if (quizDiv) {
    quizDiv.style.display = "block";
    loadQuizForLesson(lessonId, quizDiv);
  }
}

if (window.location.pathname.includes("lessons.html")) {
  loadLessons();
}

// ================== Load Quiz for a Lesson ==================
async function loadQuizForLesson(lessonId, container) {
  try {
    const res = await fetch(`/quizzes/${lessonId}`);
    if (!res.ok) {
      container.innerHTML = "<p>No quiz available for this lesson.</p>";
      return;
    }

    const quiz = await res.json();
    container.innerHTML = "<h4>Quiz</h4>";

    quiz.questions.forEach((q, i) => {
      let optionsHtml = "";
      q.options.forEach((opt, j) => {
        optionsHtml += `
          <div>
            <input type="radio" name="quiz-${lessonId}-q${i}" value="${j}">
            <label>${opt}</label>
          </div>
        `;
      });

      container.innerHTML += `
        <p><b>Q${i + 1}: ${q.question}</b></p>
        ${optionsHtml}
        <button onclick="checkLessonQuiz('${lessonId}', ${i}, ${q.answer}, '${q.question}')">Submit</button>
        <p id="result-${lessonId}-q${i}" class="fw-bold"></p>
      `;
    });
  } catch (err) {
    container.innerHTML = "<p>Error loading quiz</p>";
  }
}

// ================== Check Quiz Answer ==================
async function checkLessonQuiz(lessonId, qIndex, correctAnswer, question) {
  const selected = document.querySelector(`input[name="quiz-${lessonId}-q${qIndex}"]:checked`);
  const result = document.getElementById(`result-${lessonId}-q${qIndex}`);
  const user = localStorage.getItem("user") || "Guest";

  if (!selected) {
    result.innerText = "⚠️ Please select an option!";
    result.className = "text-warning";
    return;
  }

  const userAnswer = parseInt(selected.value);
  let message;

  if (userAnswer === correctAnswer) {
    message = "✅ Correct!";
    result.className = "text-success";
  } else {
    message = `❌ Wrong! Correct option: ${correctAnswer + 1}`;
    result.className = "text-danger";
  }

  result.innerText = message;

  // Save result in backend
  await fetch(`/results`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      user,
      question,
      userAnswer,
      correctAnswer,
      correct: userAnswer === correctAnswer
    })
  });
}

// ================== Progress ==================
async function completeLesson() {
  const user = localStorage.getItem("user") || "Guest";
  await fetch(`/progress`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ user, lessonCompleted: true })
  });

  loadProgress();
}

async function loadProgress() {
  const user = localStorage.getItem("user") || "Guest";
  const res = await fetch(`/progress/${user}`);
  const data = await res.json();

  const progressBar = document.getElementById("progressBar");
  const progressText = document.getElementById("progressText");

  if (progressBar && progressText) {
    const percent = Math.round((data.completed / data.total) * 100);
    progressBar.style.width = percent + "%";
    progressBar.innerText = percent + "%";
    progressText.innerText = `Lessons Completed: ${data.completed}/${data.total}`;
  }
}

// ================== Results Loader ==================
async function loadResults() {
  const user = localStorage.getItem("user") || "Guest";
  const res = await fetch(`/results/${user}`);
  const data = await res.json();

  const resultsDiv = document.getElementById("resultsList");
  if (resultsDiv) {
    resultsDiv.innerHTML = "";
    data.forEach(r => {
      const p = document.createElement("p");
      p.innerText = `${r.question} → Your Answer: ${r.userAnswer}, Correct: ${r.correctAnswer}`;
      resultsDiv.appendChild(p);
    });
  }
}

if (window.location.pathname.endsWith("dashboard.html")) {
  loadProgress();
  loadResults();
}

// ================== Dashboard Loader ==================
if (window.location.pathname.endsWith("dashboard.html")) {
  const currentUser = JSON.parse(localStorage.getItem('currentUser'));

  if (!currentUser) {
    window.location.href = "login.html"; // redirect if not logged in
  } else {
    document.getElementById('userName').textContent = currentUser.name;

    // Show progress
    const progressBar = document.getElementById('progressBar');
    if (progressBar) {
      const progress = currentUser.progress || 0;
      progressBar.style.width = progress + '%';
      progressBar.textContent = progress + '%';
    }

    // Show latest quizzes
    const resultsList = document.getElementById('resultsList');
    if (resultsList) {
      resultsList.innerHTML = '';
      if (currentUser.quizzes && currentUser.quizzes.length > 0) {
        currentUser.quizzes.slice(-5).reverse().forEach(q => { // last 5 quizzes
          const li = document.createElement('li');
          li.className = 'list-group-item';
          li.textContent = `${q.title} - Score: ${q.score}`;
          resultsList.appendChild(li);
        });
      } else {
        const li = document.createElement('li');
        li.className = 'list-group-item';
        li.textContent = 'No quizzes taken yet.';
        resultsList.appendChild(li);
      }
    }
  }
}
