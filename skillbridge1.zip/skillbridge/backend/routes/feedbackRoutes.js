// routes/feedbackRoutes.js
const express = require('express');
const router = express.Router();
const Feedback = require('../models/Feedback'); // ensure model exists

router.post('/', async (req, res) => {
  try {
    const { name, email, message } = req.body;
    if (!name || !email || !message) {
      return res.status(400).json({ message: 'All fields required' });
    }
    const fb = new Feedback({ name, email, message });
    await fb.save();
    res.status(201).json({ message: 'Feedback saved' });
  } catch (err) {
    console.error('Feedback save error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
