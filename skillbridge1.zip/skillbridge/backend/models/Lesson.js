// backend/models/Lesson.js
const mongoose = require("mongoose");

const lessonSchema = new mongoose.Schema({
  // custom human-friendly ID (e.g. "HTML101", "JS001")
  lessonId: { type: String, required: true, unique: true, trim: true },

  title: { type: String, required: true },
  description: { type: String, default: "" },

  // full content for the lesson (long text)
  fullContent: { type: String, default: "" },

  // optional media
  videoUrl: { type: String, default: "" },
  imageUrl: { type: String, default: "" }
}, { timestamps: true });

module.exports = mongoose.model("Lesson", lessonSchema);
